# QAMOO source-data reanalysis

Scope: reproduction of published source-data figures and numerical summaries.
This does not independently rerun the quantum experiments or MPS simulations.

The project uses the publisher's source data for Figures 2-5 and Extended Data
Figure 1, not synthetic data. It does not rerun quantum experiments or download
the complete 2.48 GB research archive. The original author notebook is preserved
for reference, not executed. `analysis.ipynb` is the executed reanalysis notebook.

## Run on Windows

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe download_data.py
.\.venv\Scripts\python.exe build_notebook.py
```

## 中文说明

本项目对应本目录 PDF《Quantum approximate multi-objective optimization》，
并非一般人工智能分类任务。复现论文图 2–5 的公开数据分析：三目标 HV 收敛、
非支配解数量、MPS 参数敏感性、四目标性能预测。先核验原始下载文件 SHA-256，
再检查时间顺序、HV 单调性、重复实验均值、区间列与硬件预测的指标变换。
已发现的源数据区间不一致记录于 `output/data_quality.csv`，用五次重复重新计算范围。

运行入口为上述三条命令，日常重新生成结果只需最后一条。
优先阅读 `output/analysis.html`，需要修改或逐步运行时打开 `analysis.ipynb`。
`output/analysis_summary.md` 给出中文数值结论。

未重跑的环节包括 27 节点参数训练、42 量子比特 MPS/IBM 硬件采样、
DCM/DPA-a 与商业求解器实验。MPS 横轴沿用论文假定采样速度，不能当成本机计时。
论文完整实验使用每个设置 5,000 电路 × 5,000 shots，并重复五次；
若要完成这一层独立实验，需要原始问题实例、训练参数、相应算力与硬件访问条件。

Alternatively, select this project's Python environment in Jupyter and run all
cells in `analysis.ipynb` with the project root as the working directory.

## Outputs

- `analysis.ipynb`: executed notebook with methods, checks, figures and conclusions.
- `output/analysis.html`: standalone reading copy.
- `output/01_*.png` through `output/04_*.png`: four 200-dpi charts.
- `output/*summary.csv`: computed numerical summaries.
- `output/time_to_9999pct.csv`: first observed threshold attainment per run.
- `output/data_quality.csv`: validation and source-bound inconsistencies.
- `output/analysis_summary.md`: Chinese conclusions and submission status.
- `output/analysis_draft_bundle.zip`: portable draft, source data included.
- `data/sources.json`: exact source URLs, byte counts and SHA-256 digests.

Data handling: source CSVs are unchanged. Pointwise min/max values are recomputed
from the five repetitions. Figure 5 hardware projections store transformed HV
gaps, not HV itself; this is checked against MPS data and the fidelity model.
No missing hardware measurements are invented. MPS time is the paper's assumed
sampling time, not measured simulator wall time. Reported repeat ranges are not
confidence intervals. No claim of general quantum advantage is made.

Paper DOI: 10.1038/s43588-025-00873-y
Data archive DOI: 10.5281/zenodo.16878920
