"""Portable verification and exact sampling replay for the submitted experiments.

Python 3.10; install requirements-reproduce.txt first. No IBM account or solver.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import time
import sys
import numpy as np
import networkx as nx
import moocore

BASE=Path(__file__).resolve().parent
DATA=BASE/'experiments'


def evaluate(bits,graphs):
    return np.column_stack([sum(float(d['weight'])*(bits[:,u]!=bits[:,v]) for u,v,d in g.edges(data=True)) for g in graphs])


def hv_independent(values,reference):
    # Independently compute the union of lower-reference-anchored 3D boxes.
    points=values-np.asarray(reference)
    points=points[np.all(points>0,axis=1)]
    volume,previous=0.,0.
    for x in np.unique(points[:,0]):
        yz=points[points[:,0]>=x,1:]
        yz=yz[np.argsort(yz[:,0])]
        area=np.dot(np.diff(np.r_[0.,yz[:,0]]),np.maximum.accumulate(yz[::-1,1])[::-1])
        volume+=(x-previous)*area
        previous=x
    return float(volume)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode',choices=['verify','replay'],default='verify')
    parser.add_argument('--all',action='store_true',help='Replay all five seeds rather than only the first seed at each depth.')
    args=parser.parse_args()
    config=json.loads((DATA/'config.json').read_text(encoding='utf-8'))
    ref=config['reference_point']
    graphs=[nx.node_link_graph(json.loads((DATA/f'inputs/problem_graph_{j}.json').read_text()),edges='links') for j in range(3)]
    rows=list(csv.DictReader((DATA/'results.csv').open(encoding='utf-8-sig')))
    checks=[]
    for item in json.loads((DATA/'input_manifest.json').read_text(encoding='utf-8')):
        if 'copy' in item:
            assert hashlib.sha256((DATA/item['copy']).read_bytes()).hexdigest()==item['sha256']
    if args.mode=='verify':
        for row in rows:
            p,seed=int(row['p']),int(row['seed'])
            raw=np.load(DATA/f'runs/p{p}_seed{seed}.npz')
            bits,values=raw['bits'],raw['objectives']
            assert bits.shape==(10000,42) and np.isin(bits,[0,1]).all()
            evaluated=evaluate(bits,graphs)
            assert np.allclose(evaluated,values,atol=1e-12,rtol=0)
            front=np.flatnonzero(moocore.is_nondominated(values,maximise=True,keep_weakly=False))
            assert np.array_equal(front,raw['front'])
            hv=float(moocore.hypervolume(values,ref=ref,maximise=True))
            assert abs(hv-float(row['hypervolume']))<1e-7
            assert abs(hv-hv_independent(values[front],ref))<1e-7
            if p==0:
                expected=np.random.RandomState(seed).randint(0,2,size=(10000,42),dtype='b')
                assert np.array_equal(bits,expected)
            checks.append({'p':p,'seed':seed,'samples':len(bits),'all_objectives_recomputed':True,'hv':hv})
        curve_rows=list(csv.DictReader((DATA/'curves.csv').open(encoding='utf-8-sig')))
        for curve in curve_rows:
            p,seed,n=int(curve['p']),int(curve['seed']),int(curve['shots'])
            values=np.load(DATA/f'runs/p{p}_seed{seed}.npz')['objectives'][:n]
            actual=moocore.hypervolume(values,ref=ref,maximise=True)
            assert abs(float(curve['hypervolume'])-actual)<1e-7
        output={'mode':'verify','passed':True,'runs':len(checks),'samples':200000,'curve_points':len(curve_rows),'checks':checks}
        (BASE/'qa/portable_verification.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
        print('PASS: 20 runs, 200000 samples, all objective vectors, 200 curve points, independent HV, input hashes.')
    else:
        from qiskit import qpy
        from qiskit.primitives import BackendSamplerV2
        from qiskit_aer import AerSimulator
        for p in config['depths']:
            folder=DATA/f'inputs/p{p}'
            with (folder/'transpiled_parametrized_circuit.qpy').open('rb') as f:
                circuit=qpy.load(f)[0]
            bindings=json.loads((folder/'parameter_dicts.json').read_text())
            values=[[b[key.name] for key in circuit.parameters] for b in bindings]
            for seed in config['seeds'] if args.all else config['seeds'][:1]:
                backend=AerSimulator(method='matrix_product_state',matrix_product_state_max_bond_dimension=config['chi'],max_parallel_threads=1)
                sampler=BackendSamplerV2(backend=backend,options={'seed_simulator':seed})
                t=time.perf_counter()
                bitstrings=sampler.run([(circuit,values,config['shots_per_circuit'])]).result()[0].data.meas.get_bitstrings()
                bits=np.array([[int(x) for x in s[::-1]] for s in bitstrings],dtype=np.int8)
                original=np.load(DATA/f'runs/p{p}_seed{seed}.npz')['bits']
                assert np.array_equal(bits,original),(p,seed,'replay mismatch')
                checks.append({'p':p,'seed':seed,'samples':len(bits),'bitwise_identical':True,'wall_s':time.perf_counter()-t})
                print(f'PASS: replay p={p}, seed={seed}, {len(bits)} bitwise-identical samples.',flush=True)
        (BASE/'qa/replay_verification.json').write_text(json.dumps({'mode':'replay','passed':True,'checks':checks},indent=2),encoding='utf-8')


if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
