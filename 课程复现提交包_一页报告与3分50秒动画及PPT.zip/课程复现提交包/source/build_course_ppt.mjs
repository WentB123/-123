import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {Presentation,PresentationFile} from '@oai/artifact-tool';
const workspaceDir='E:/复现/人工智能';
const SKILL_DIR='C:/Users/WentB/.codex/plugins/cache/openai-primary-runtime/presentations/26.1105.12137/skills/presentations';
const RUNTIME_PYTHON='C:/Users/WentB/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
process.env.RUNTIME_NODE_MODULES='C:/Users/WentB/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';
const build=path.join(workspaceDir,'tmp/course_ppt_build'),out=path.join(workspaceDir,'output/course_delivery'),qa=path.join(out,'qa/ppt');
const FINAL_PPTX=path.join(out,'答辩PPT_3分50秒_可编辑.pptx');
const {finalizePresentation,applyPresentationChartFont}=await import(pathToFileURL(path.join(SKILL_DIR,'container_tools/artifact_tool_utils.mjs')).href);
const scenes=JSON.parse(await fs.readFile(path.join(out,'storyboard.json'),'utf8'));
const stats=JSON.parse(await fs.readFile(path.join(out,'experiments/summary.json'),'utf8'));
const graph=JSON.parse(await fs.readFile(path.join(build,'graph.json'),'utf8'));
const rows=(await fs.readFile(path.join(out,'experiments/curves.csv'),'utf8')).replace(/^\uFEFF/,'').trim().split(/\r?\n/).slice(1).map(s=>{const [method,p,seed,shots,hv]=s.split(',');return {p:+p,shots:+shots,hv:+hv};});
const FONT='Microsoft YaHei',C={bg:'#F6F8FA',ink:'#173345',muted:'#5F727E',teal:'#087E82',blue:'#416E9B',gold:'#CB8D36',line:'#DCE4E9',light:'#D8EEEB'};
const colors=['#86929D','#A6B9D0',C.blue,C.teal],names=['均匀随机','QAOA p=1','QAOA p=3','QAOA p=6'];
const presentation=Presentation.create({slideSize:{width:1280,height:720}});
function rect(s,x,y,w,h,fill){return s.shapes.add({geometry:'rect',position:{left:x,top:y,width:w,height:h},fill,line:{fill:'none',width:0}});}
function txt(s,str,x,y,w,h,size=28,color=C.ink,bold=false){const q=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});q.text=str;q.text.style={typeface:FONT,fontSize:size,color,bold};q.text.insets=0;return q;}
function line(s,x1,y1,x2,y2,color=C.line,width=2){return s.shapes.add({geometry:'line',position:{left:Math.min(x1,x2),top:Math.min(y1,y2),width:Math.max(1,Math.abs(x2-x1)),height:Math.max(1,Math.abs(y2-y1)),verticalFlip:(x2-x1)*(y2-y1)<0},fill:'none',line:{fill:color,width}});}
function dot(s,x,y,r,fill){return s.shapes.add({geometry:'ellipse',position:{left:x-r,top:y-r,width:2*r,height:2*r},fill,line:{fill:'white',width:1.5}});}
function stamp(t){return `${Math.floor(t/60).toString().padStart(2,'0')}:${(t%60).toString().padStart(2,'0')}`;}
function slide(i,title){const s=presentation.slides.add();s.background.fill=C.bg;rect(s,0,0,1280,10,C.teal);txt(s,title,64,67,1150,73,42,C.ink,true);line(s,64,161,1216,161);const sc=scenes[i];txt(s,`${stamp(sc.start)}–${stamp(sc.start+sc.duration)}  ·  ${i+1}/7`,64,666,580,26,18,C.muted);s.speakerNotes.text=`建议讲解时段：${stamp(sc.start)}–${stamp(sc.start+sc.duration)}（${sc.duration} 秒）\n\n${sc.narration.join('\n\n')}\n\n来源：Kotil et al., Quantum approximate multi-objective optimization, Nature Computational Science 5, 1168–1177 (2025). https://doi.org/10.1038/s43588-025-00873-y\n作者代码：https://github.com/stefan-woerner/qamoo\n本机数据：experiments/results.csv；experiments/curves.csv；experiments/verification.json。全部结果来自已完成的缩小预算实验。`;return s;}
{
 const s=slide(0,'量子多目标优化实验复现');
 txt(s,'42 节点 · 3 个目标',72,225,760,84,54,C.teal,true);
 txt(s,'用 QAOA 采样寻找更好的折中解集',74,325,805,58,32);
 txt(s,'比较电路深度 p=1、3、6 与均匀随机采样',74,395,1000,50,28,C.muted);
 txt(s,'20 次运行',76,500,360,70,44,C.ink,true);txt(s,'200,000 条新样本',510,500,670,70,44,C.ink,true);
 txt(s,'课程范围：理想电路的 MPS 近似模拟',76,583,1000,38,23,C.muted);
}
{
 const s=slide(1,'同一个切分，得到三个目标分数');
 const nodes=new Map(graph.nodes.map(n=>[n.id,{...n,x:80+(n.x-82)*.95,y:227+(n.y-195)*.95}]));
 for(const e of graph.edges){const a=nodes.get(e.u),b=nodes.get(e.v);line(s,a.x,a.y,b.x,b.y,e.cut?C.teal:C.line,e.cut?3:1.5);}
 for(const n of nodes.values())dot(s,n.x,n.y,8,n.bit?C.gold:C.blue);
 txt(s,'42 个节点分为两组',700,212,510,50,31,C.ink,true);
 txt(s,'跨组边的权重之和 = 最大割得分',700,282,510,76,28);
 txt(s,'连接结构相同，三个目标的边权不同',700,379,510,80,26,C.muted);
 for(let j=0;j<3;j++){txt(s,`f${j+1}`,704+j*163,489,140,40,24,[C.teal,C.blue,C.gold][j],true);txt(s,graph.values[j].toFixed(2),704+j*163,536,145,57,37,[C.teal,C.blue,C.gold][j],true);}
 txt(s,'图示来自本次 p=6 的一个真实测量样本',82,600,960,34,20,C.muted);
}
{
 const s=slide(2,'用 Pareto 非支配解与 HV 评价解集');
 const px=x=>125+x*73,py=y=>555-y*51;
 for(const p of [[3,5],[4,4],[5,3],[6,2]])rect(s,125,py(p[1]),p[0]*73,555-py(p[1]),C.light);
 line(s,125,220,125,555,C.muted,2);line(s,125,555,662,555,C.muted,2);
 for(const p of [[1,2],[2,1],[2,3],[3,2],[4,3]])dot(s,px(p[0]),py(p[1]),6,'#C6D0D8');
 const front=[[3,5],[4,4],[5,3],[6,2]];front.forEach((p,j)=>{dot(s,px(p[0]),py(p[1]),10,C.teal);if(j)line(s,px(front[j-1][0]),py(front[j-1][1]),px(p[0]),py(p[1]),C.teal,3);});
 txt(s,'目标二 ↑',102,185,280,37,22,C.muted);txt(s,'目标一 →',423,574,210,38,22,C.muted);txt(s,'参考点',125,563,140,34,20,C.muted);
 txt(s,'保留不能被全面改进的方案',745,229,463,87,30,C.ink,true);
 txt(s,'HV 越大，覆盖的目标空间越大',745,349,463,100,30,C.teal,true);
 txt(s,'左图是二维教学示意\n实测使用三个目标与固定参考点',745,500,463,90,24,C.muted);
}
{
 const s=slide(3,'固定输入后，重新生成测量样本');
 const steps=[['公开问题','42 节点 / 3 目标'],['参数迁移','27 节点训练角度'],['电路采样','p=1 / 3 / 6'],['解集评价','Pareto → HV']];
 for(let j=0;j<4;j++){const x=72+j*294;txt(s,steps[j][0],x,227,252,53,32,j===2?C.teal:C.ink,true);txt(s,steps[j][1],x,295,260,70,23,C.muted);if(j<3)txt(s,'→',x+247,241,45,49,30,C.teal);}
 line(s,72,402,1208,402);txt(s,'10 电路 × 1,000 shots × 5 个种子 / 方法',72,440,1140,70,37,C.ink,true);
 txt(s,'MPS 键维数 χ=20；前 10 个权重向量固定共享',74,529,1130,46,28,C.teal);
 txt(s,'随机对照同样每次 10,000 样本；共 20 次运行、20 万条样本',74,593,1130,41,25,C.muted);
}
{
 const s=slide(4,'p=6 在本实例上取得更高的 HV');
 const categories=Array.from({length:10},(_,i)=>String(i+1));
 const series=[0,1,3,6].map((p,j)=>({name:names[j],values:categories.map((_,i)=>{const values=rows.filter(r=>r.p===p&&r.shots===(i+1)*1000).map(r=>r.hv);if(values.length!==5)throw Error('Missing replicate');return Number((values.reduce((a,b)=>a+b,0)/5/1000).toFixed(8));}),fill:colors[j],line:{fill:colors[j],width:j===3?3:2},marker:{symbol:'none'}}));
 const ch=s.charts.add('line',{position:{left:66,top:193,width:830,height:400},categories,series,hasLegend:true,legend:{position:'bottom',textStyle:{fontSize:19}},lineOptions:{smooth:false},xAxis:{title:{text:'累计样本数（千条）',textStyle:{fontSize:20}},textStyle:{fontSize:18},numberFormatCode:'0'},yAxis:{min:15,max:45,majorUnit:10,title:{text:'超体积 HV（千）',textStyle:{fontSize:20}},textStyle:{fontSize:18},numberFormatCode:'0',majorGridlines:{fill:C.line,width:1}},chartFill:'none',chartLine:{fill:'none',width:0},plotAreaFill:'none',plotAreaLine:{fill:'none',width:0}});
 applyPresentationChartFont(ch,{fontFamily:FONT});const gain=(stats[3].hypervolume_mean/stats[0].hypervolume_mean-1)*100;
 txt(s,`+${gain.toFixed(1)}%`,948,230,277,87,58,C.teal,true);txt(s,'p=6 相对均匀随机\n平均 HV 提升',948,329,270,98,26);txt(s,'同样本数比较\n不代表同耗时',948,478,270,85,25,C.muted);
 txt(s,'图示 5 次重复的均值；测量波动见下一页 SD。全部观测均纳入计算。',78,612,1140,39,20,C.muted);
}
{
 const s=slide(5,'20 次运行的原始记录均可核验');
 const vals=[['方法','HV 均值 ± SD','非支配解数均值'],...stats.map((r,j)=>[names[j],`${Math.round(r.hypervolume_mean).toLocaleString('en-US')} ± ${Math.round(r.hypervolume_std)}`,r.non_dominated_vectors_mean.toFixed(1)])];
 const t=s.tables.add({rows:5,columns:3,left:72,top:205,width:1136,height:300,columnWidths:[300,420,416],values:vals});t.borders.assign({fill:C.line,width:1,style:'solid'});
 for(let r=0;r<5;r++)for(let c=0;c<3;c++){const cell=t.getCell(r,c);cell.fill=r===0?'#E4EFF0':C.bg;cell.text.style={typeface:FONT,fontSize:r===0?25:29,color:r===0?C.ink:(c===0?colors[r-1]:C.ink),bold:r===0||c===0};}
 txt(s,'独立三维 HV 核验通过；另外 30,000 样本重放逐位一致',76,548,1130,48,27,C.teal,true);txt(s,'n=5；同一问题与权重子集。SD 为样本标准差，非置信区间。',76,610,1130,36,21,C.muted);
}
{
 const s=slide(6,'结论限定于本实例的解集质量改善');txt(s,'p=6 得到了更好的近似解集',75,214,1140,74,43,C.teal,true);txt(s,'每次 1 万样本 = 论文三目标实验每次预算的 1 / 2,500',77,310,1130,55,29);line(s,76,398,1207,398);
 txt(s,'本次完成',77,436,500,49,30,C.ink,true);txt(s,'新样本 → 非支配解 → HV\n同样本数随机对照与完整记录',77,502,525,100,27);txt(s,'复现边界',708,436,497,49,30,C.ink,true);txt(s,'复用训练角度，未重跑真机\n未完成全部强经典对比\n不宣称量子加速',708,502,497,123,26,C.muted);
}
await fs.mkdir(qa,{recursive:true});
for(const [i,s] of presentation.slides.items.entries()){const blob=await presentation.export({slide:s,format:'png',scale:1});await fs.writeFile(path.join(qa,`slide_${i+1}.png`),new Uint8Array(await blob.arrayBuffer()));}
const candidatePath=path.join(build,'draft.pptx');await (await PresentationFile.exportPptx(presentation)).save(candidatePath);
const result=await finalizePresentation({workspaceDir,candidatePath,finalPath:FINAL_PPTX,pythonExecutable:RUNTIME_PYTHON,integrityValidatorPath:path.join(SKILL_DIR,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(SKILL_DIR,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit','--require-native-table-slide','6'],explicitTotalSlideCount:7,requiredNativeTableOwnerSlides:[6],requiredNativeChartOwnerSlides:[5],materializeLiteralChartWorkbooks:true,fontPolicy:{basis:'design',families:[FONT]},verifyArtifactToolImport:true,receiptPath:path.join(build,'validation.json')});
await fs.writeFile(path.join(build,'result.json'),JSON.stringify(result,null,2));console.log('PPTX COMPLETE',FINAL_PPTX);
